#include "display.h"

Display::Display() {}

void Display::displayText(String) {
    // no-op
}

void Display::displayHomeScreen(String, String, String) {
    // no-op
}
